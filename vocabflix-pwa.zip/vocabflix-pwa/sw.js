const CACHE_NAME = 'vocabflix-v2';
const ASSETS = ['/', '/index.html'];

// ── Install: cache core files
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE_NAME).then(c => c.addAll(ASSETS))
  );
  self.skipWaiting();
});

// ── Activate: clean old caches
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// ── Fetch: serve from cache, fallback to network
self.addEventListener('fetch', e => {
  // Don't intercept API calls
  if (e.request.url.includes('api.anthropic.com')) return;
  e.respondWith(
    caches.match(e.request).then(r => r || fetch(e.request))
  );
});

// ── Push notification received
self.addEventListener('push', e => {
  const data = e.data ? e.data.json() : {};
  e.waitUntil(
    self.registration.showNotification(data.title || 'VocabFlix', {
      body: data.body || '복습할 단어가 있어요!',
      icon: '/icon-192.png',
      badge: '/icon-192.png',
      tag: 'quiz-reminder',
      renotify: true,
      data: { url: '/' }
    })
  );
});

// ── Notification click → open app
self.addEventListener('notificationclick', e => {
  e.notification.close();
  e.waitUntil(
    clients.matchAll({ type: 'window' }).then(clientList => {
      for (const c of clientList) {
        if (c.url === '/' && 'focus' in c) return c.focus();
      }
      if (clients.openWindow) return clients.openWindow('/');
    })
  );
});

// ── Periodic background sync (where supported)
self.addEventListener('periodicsync', e => {
  if (e.tag === 'quiz-reminder') {
    e.waitUntil(checkAndNotify());
  }
});

async function checkAndNotify() {
  // Read due count from IndexedDB
  const db = await openDB();
  const words = await getAllWords(db);
  const SCHEDULE = [
    { day: 1 }, { day: 2 }, { day: 5 }, { day: 10 }
  ];
  let dueCount = 0;
  words.forEach(w => {
    SCHEDULE.forEach((s, si) => {
      if (w.completedSteps && w.completedSteps.includes(si)) return;
      if (Date.now() >= w.addedAt + s.day * 86400000) dueCount++;
    });
  });

  if (dueCount > 0) {
    await self.registration.showNotification('VocabFlix 복습 알림 🔔', {
      body: `미완료 퀴즈 ${dueCount}개가 있어요. 지금 복습해보세요!`,
      icon: '/icon-192.png',
      tag: 'quiz-reminder',
      renotify: true
    });
  }
}

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open('vocabflix_db', 1);
    req.onsuccess = e => resolve(e.target.result);
    req.onerror = reject;
  });
}

function getAllWords(db) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction('words', 'readonly');
    const req = tx.objectStore('words').getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = reject;
  });
}
